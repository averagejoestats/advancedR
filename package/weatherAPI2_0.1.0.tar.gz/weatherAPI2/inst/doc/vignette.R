## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(weatherAPI2)

## -----------------------------------------------------------------------------
# get weather forecast for Ithaca, NY
data("upstate_cities")
print( upstate_cities )
ii <- which( upstate_cities$name == "Ithaca" )
grid_info <- get_geo_data( upstate_cities$lat[ii], upstate_cities$lon[ii] )
forecast <- get_7day_forecast( grid_info )
print( forecast, nperiods = 4 )

