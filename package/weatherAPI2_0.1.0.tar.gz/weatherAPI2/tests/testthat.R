library(testthat)
library(weatherAPI2)

test_check("weatherAPI2")
